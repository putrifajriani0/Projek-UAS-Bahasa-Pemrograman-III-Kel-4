<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// =====================
// AUTH (NO FILTER)
// =====================
$routes->get('auth', 'Auth::index');
$routes->post('auth/login', 'Auth::login');
$routes->get('auth/logout', 'Auth::logout');

// =====================
// DASHBOARD (PROTECTED)
// =====================
$routes->get('/', 'Dashboard::index', ['filter' => 'auth']);

// =====================
// PROTECTED ROUTES
// =====================
$routes->group('', ['filter' => 'auth'], function ($routes) {

    $routes->resource('products');
    $routes->resource('categories');
    $routes->resource('vendors');

    $routes->resource('purchases');

    $routes->resource('incoming', [
        'controller' => 'IncomingItems'
    ]);

    $routes->resource('outgoing', [
        'controller' => 'Outcoming'
    ]);

    // REPORTS
    $routes->group('reports', function ($routes) {
        $routes->get('incoming', 'Reports::incoming');
        $routes->get('outgoing', 'Reports::outgoing');
        $routes->get('stock', 'Reports::stock');
    });
});

// =====================
// API (OPTIONAL)
// =====================
$routes->get('api/purchase-items/(:num)', 'Api::purchaseItems/$1');
