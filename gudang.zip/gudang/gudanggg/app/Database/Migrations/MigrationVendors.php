<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class MigrationVendors extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'name' => [
                'type'       => 'VARCHAR',
                'constraint' => '100',
            ],
            'address' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'phone' => [
                'type' => 'VARCHAR',
                'constraint' => '30',
                'null' => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'default' => 'current_timestamp()',
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'default' => 'current_timestamp()',
                'on_update' => 'current_timestamp()',
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->createTable('vendors');
    }

    public function down()
    {
        $this->forge->dropTable('vendors');
    }
}
