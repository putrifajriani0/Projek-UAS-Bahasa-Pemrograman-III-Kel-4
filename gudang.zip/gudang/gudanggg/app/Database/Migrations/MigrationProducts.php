<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class MigrationProducts extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true,
            ],
            'category_id' => [
                'type' => 'INT',
                'constraint' => 11,
                'null' => true,
            ],
            'name' => [
                'type' => 'VARCHAR',
                'constraint' => '100',
            ],
            'code' => [
                'type' => 'VARCHAR',
                'constraint' => '50',
            ],
            'unit' => [
                'type' => 'VARCHAR',
                'constraint' => '20',
            ],
            'stock' => [
                'type' => 'DECIMAL',
                'constraint' => '10,2',
                'default' => 0.00,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'default' => 'current_timestamp()',
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'default' => 'current_timestamp()',
                'on_update' => 'current_timestamp()',
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('code');
        $this->forge->addForeignKey('category_id', 'categories', 'id', 'SET NULL', 'CASCADE');
        $this->forge->createTable('products');
    }

    public function down()
    {
        $this->forge->dropTable('products');
    }
}
