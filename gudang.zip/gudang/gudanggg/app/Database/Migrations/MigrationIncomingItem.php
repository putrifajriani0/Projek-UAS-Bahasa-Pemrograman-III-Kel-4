<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class MigrationIncomingItem extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => ['type'=>'INT','constraint'=>11,'unsigned'=>true,'auto_increment'=>true],
            'product_id' => ['type'=>'INT','constraint'=>11],
            'purchase_item_id' => ['type'=>'INT','constraint'=>11,'null'=>true],
            'date' => ['type'=>'DATETIME'],
            'quantity' => ['type'=>'DECIMAL','constraint'=>'10,2'],
            'created_at' => ['type'=>'DATETIME','default'=>'current_timestamp()'],
            'updated_at' => ['type'=>'DATETIME','default'=>'current_timestamp()','on_update'=>'current_timestamp()'],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('purchase_item_id');
        $this->forge->addForeignKey('product_id','products','id','CASCADE','CASCADE');
        $this->forge->addForeignKey('purchase_item_id','purchase_items','id','SET NULL','CASCADE');
        $this->forge->createTable('incoming_items');
    }

    public function down()
    {
        $this->forge->dropTable('incoming_items');
    }
}
